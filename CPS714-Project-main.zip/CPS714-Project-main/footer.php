<?php
if (count(get_included_files()) == 1) exit("Direct access denied.");
?>
<style>
    .footer {
        /* background: linear-gradient(to bottom, #0000ff, #00bfff);
        background: linear-gradient(to bottom, #404, #202);
        color: #999; */
        background-color: #495E57;
    }
</style>
<footer class="text-center text-lg-start footer">
    <div class="text-center p-3" style="color: #F4CE14;">
        © iFitness<sup>TM</sup> 2023
    </div>
</footer>